package com.cg.pl;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.exception.AccountException;
import com.cg.service.IService;
import com.cg.service.ServiceImpl;

public class Client {

	public static void main(String[] args) throws AccountException {
		// TODO Auto-generated method stub
		IService service = new ServiceImpl();
		System.out.println("----Welcome to MyWallet----");
		long accNo = 10000;
		int ch=0;
		do {
			System.out.println("Press 1--> Create Account\nPress 2--> Display Account details\nPress 3--> Deposit\nPress 4--> Withdraw\nPress 5--> Fund Transfer\nPress 6--> Show Transactions");
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter your choice: ");
			ch = sc.nextInt();
			switch(ch) {
			case 1:
				while(true) {
				System.out.print("Enter Account Holder name: ");
				String name = sc.next();
				if(service.nameValidation(name)) {
					accNo ++;
						while(true) {
							System.out.print("Enter opening account balance: ");
							double openingBal = sc.nextDouble();
							if(openingBal>=1000) {
								Account acc = new Account(name,accNo,openingBal);
								System.out.println("Your Account is created successfully with Account Number: "+service.addAccount(acc));
							break;
							}else
								System.out.println("---Minimum Account balance should be more than or equal to 1000---");
						}
				break;
				}
				}
			break;
			case 2:
				System.out.print("Enter Account number: ");
				long accNoDetails = sc.nextLong();
				if(service.findAccount(accNoDetails) == true )
					System.out.println("Your Account details:\n"+service.showAccountDetails(accNoDetails));
				else
					System.out.println("---Enter Valid Account Number---");
			break;
			case 3:
				System.out.print("Enter your Account Number: ");
				long accNoDeposit = sc.nextLong();
				if(service.findAccount(accNoDeposit)== true) {
					System.out.println("Enter the amount to be deposited");
					double amount = sc.nextDouble();
					double updatedBal = service.deposit(accNoDeposit, amount);
					System.out.println("Your Account is deposited with the amount of Rs."+amount);
					System.out.println("Your Account Updated balance is Rs."+updatedBal);
				}else
				System.out.println("---Oops Account not Found---");
			break;
			case 4:
				System.out.print("Enter your Account Number: ");
				long accNoWithdraw = sc.nextLong();
				if(service.findAccount(accNoWithdraw)== true) {
					System.out.println("Enter the amount to be withdrawn");
					double amount = sc.nextDouble();
					if(service.minBalCheck(accNoWithdraw, amount)==true) {
						double updatedBal = service.withdraw(accNoWithdraw, amount);
						System.out.println("Your Account is debited with the amount of Rs."+amount);
						System.out.println("Your Account Updated balance is Rs."+updatedBal);
					}else
						System.out.println("---Insufficient funds---");
				}else
					System.out.println("---Oops Account not Found---");
			break;
			case 5:
				System.out.print("Enter your Account Number: ");
				long fromAccNo = sc.nextLong();
				if(service.findAccount(fromAccNo)==true) {
					System.out.print("Enter the Account Number to be credited: ");
					long toAccNo = sc.nextLong();
					if(service.findAccount(toAccNo)==true) {
						System.out.print("Enter the amount to be credited: ");
						double amount = sc.nextDouble();
						if(service.minBalCheck(fromAccNo, amount)==true) {
							double updatedBal = service.fundTransfer(fromAccNo, toAccNo, amount);
							System.out.println("Fund transfer of Rs."+amount+" to Account Number "+toAccNo+" is Successful");
							System.out.println("Your Account updated balance is Rs."+updatedBal);
						}else
							System.out.println("---Insufficient funds---");
					}else
						System.out.println("---Invalid credit Account Number---");
				}else
						System.out.println("---Invalid Account Number---");
			break;
			case 6:
				System.out.println("Enter your Account Number: ");
				long transAccNo = sc.nextLong();
				if(service.findAccount(transAccNo)==true) {
					List<Transaction> tranList=null;
					tranList = service.showTransactions(transAccNo);
					System.out.println(transAccNo+"Account's transactions are: ");
					for(Transaction tc:tranList){
						System.out.println(tc);
					}
				}
				break;
			} 
			System.out.println("If you want to continue press '1' or else press '0' to exit");
			ch = sc.nextInt();
		}while(ch!=0);
	}
}
