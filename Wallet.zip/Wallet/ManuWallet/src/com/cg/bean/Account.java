package com.cg.bean;

public class Account {

	private String name;
	private long accNo;
	private double accBal;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(String name, long accNo, double accBal) {
		super();
		this.name = name;
		this.accNo = accNo;
		this.accBal = accBal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public double getAccBal() {
		return accBal;
	}

	public void setAccBal(double accBal) {
		this.accBal = accBal;
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", accNo=" + accNo + ", accBal=" + accBal + "]";
	}	
}
