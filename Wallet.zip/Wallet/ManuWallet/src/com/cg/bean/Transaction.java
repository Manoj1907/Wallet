package com.cg.bean;

import java.time.LocalDateTime;

public class Transaction {

	private int transSeq;
	private String transType;
	private double amount;
	private double updatedBal;
	private LocalDateTime date;
	private long transId;
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transSeq,long transId, String transType,double amount, double updatedBal, LocalDateTime date) {
		super();
		this.amount = amount;
		this.updatedBal = updatedBal;
		this.date = date;
		this.transType = transType;
		this.transId = transId;
		this.transSeq = transSeq;
	}

	public int getTransSeq() {
		return transSeq;
	}

	public void setTransSeq(int transSeq) {
		this.transSeq = transSeq;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getUpdatedBal() {
		return updatedBal;
	}

	public void setUpdatedBal(double updatedBal) {
		this.updatedBal = updatedBal;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	@Override
	public String toString() {
		return "Transaction [transSeq=" + transSeq + ", transType=" + transType + ", amount=" + amount + ", updatedBal="
				+ updatedBal + ", date=" + date + "]";
	}

}
