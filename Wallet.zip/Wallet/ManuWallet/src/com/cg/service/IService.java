package com.cg.service;

import java.util.List;
import com.cg.bean.Account;
import com.cg.bean.Transaction;

public interface IService {
	
	public long addAccount(Account acc);
	public boolean nameValidation(String name);
	public Account showAccountDetails(long accNo);
	public boolean findAccount(long accNo);
	public double deposit(long accNo, double amount);
	public boolean minBalCheck(long accNo, double amount);
	public double withdraw(long accNo,double amount);
	public double fundTransfer(long fromAccNo,long toAccNo,double amount);
	public List<Transaction> showTransactions(long accNo);
	
}
