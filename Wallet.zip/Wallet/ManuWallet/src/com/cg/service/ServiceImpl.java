package com.cg.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.dao.DaoImpl;
import com.cg.dao.IDao;

public class ServiceImpl implements IService {
	
	IDao dao = new DaoImpl();

	@Override
	public long addAccount(Account acc) {
		return dao.addAccount(acc);
	}
	
	@Override
	public boolean nameValidation(String name) {
		String pattern = "[A-Z]{1}[a-z]{2,}";
		return Pattern.matches(pattern,name);
	}

	@Override
	public Account showAccountDetails(long accNo) {
		return dao.showAccountDetails(accNo);
	}
	
	@Override
	public boolean findAccount(long accNo) {
		return dao.findAccount(accNo);
	}

	@Override
	public double deposit(long accNo, double amount) {
		return dao.deposit(accNo, amount);
	}
	
	@Override
	public double withdraw(long accNo, double amount) {
		return dao.withdraw(accNo, amount);
	}
	
	@Override
	public boolean minBalCheck(long accNo, double amount) {
		return dao.minBalCheck(accNo, amount);
	}
	
	@Override
	public double fundTransfer(long fromAccNo, long toAccNo,double amount) {
		return dao.fundTransfer(fromAccNo, toAccNo, amount);
	}


	@Override
	public List<Transaction> showTransactions(long accNo){
		return dao.showTransactions(accNo);
	}

}
