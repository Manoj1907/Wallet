package com.cg.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.staticdb.StaticDB;

public class DaoImpl implements IDao {
	
	String type;
	LocalDateTime now = LocalDateTime.now(); 
	
	@Override
	public int getTranSeq() {
		return ++StaticDB.transSeq;
	}
	
	@Override
	public long addAccount(Account acc) {
		StaticDB.getAccounts().put(acc.getAccNo(),acc);
		long transId = (acc.getAccNo()*2)+1;
		type = "AccountOpening";
		Transaction trans = new Transaction(++StaticDB.transSeq,transId,type,acc.getAccBal(),acc.getAccBal(),now);
		StaticDB.getTransactions().put(trans.getTransSeq(),trans);
		return acc.getAccNo();
	}

	@Override
	public Account showAccountDetails(long accNo) {
		return StaticDB.getAccounts().get(accNo);
	}
	
	@Override
	public boolean findAccount(long accNo) {
		if(StaticDB.getAccounts().containsKey(accNo))
			return true;
		else
			return false;
	}

	@Override
	public double deposit(long accNo, double amount) {
		double balance = StaticDB.getAccounts().get(accNo).getAccBal()+amount;
		StaticDB.getAccounts().get(accNo).setAccBal(balance);
		double updatedBal = StaticDB.getAccounts().get(accNo).getAccBal();
		long transId = (accNo*2)+1;
		type = "Deposit";
		Transaction trans = new Transaction(++StaticDB.transSeq,transId,type,amount,updatedBal,now);
		StaticDB.getTransactions().put(trans.getTransSeq(),trans);
		return updatedBal;
	}
	
	@Override
	public boolean minBalCheck(long accNo, double amount) {
		double balance = StaticDB.getAccounts().get(accNo).getAccBal();
		if((balance-amount) >= 1000)
			return true;
		else
			return false;
		
	}
	
	@Override
	public double withdraw(long accNo, double amount) {
		double balance = StaticDB.getAccounts().get(accNo).getAccBal()-amount;
		StaticDB.getAccounts().get(accNo).setAccBal(balance);
		double updatedBal = StaticDB.getAccounts().get(accNo).getAccBal();
		long transId = (accNo*2)+1;
		type = "Withdraw";
		Transaction trans = new Transaction(++StaticDB.transSeq,transId,type,amount,updatedBal,now);
		StaticDB.getTransactions().put(trans.getTransSeq(),trans);
		return updatedBal;
	}
	
	@Override
	public double fundTransfer(long fromAccNo, long toAccNo, double amount) {
		double balance = StaticDB.getAccounts().get(fromAccNo).getAccBal()-amount;
		StaticDB.getAccounts().get(fromAccNo).setAccBal(balance);
		long transId1 = (fromAccNo*2)+1;
		type = "Fund Transfer";
		Transaction trans = new Transaction(++StaticDB.transSeq,transId1,type,amount,balance,now);
		StaticDB.getTransactions().put(trans.getTransSeq(),trans);
		double balance2 = StaticDB.getAccounts().get(toAccNo).getAccBal()+amount;
		StaticDB.getAccounts().get(toAccNo).setAccBal(balance2);
		long transId2 = (toAccNo*2)+1;
		type = "Fund Transfer";
		Transaction trans1 = new Transaction(++StaticDB.transSeq,transId2,type,amount,balance2,now);
		StaticDB.getTransactions().put(trans1.getTransSeq(),trans1);
		return balance;
	}

	@Override
	public List<Transaction> showTransactions(long accNo) {
		List<Transaction> tranList= new ArrayList<Transaction>(StaticDB.getTransactions().values());
		List<Transaction> sortTranList=new ArrayList<Transaction>();
		long tId= (accNo*2)+1;
		for(Transaction ts:tranList){
			if(ts.getTransId()==tId){
				sortTranList.add(ts);
			}
		}
		return sortTranList;
	}
	
}
