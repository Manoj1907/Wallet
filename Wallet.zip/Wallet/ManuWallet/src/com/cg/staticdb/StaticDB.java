package com.cg.staticdb;

import java.util.HashMap;

import com.cg.bean.Account;
import com.cg.bean.Transaction;

public class StaticDB {
	
	public static int transSeq = 0;
	
	static HashMap<Long,Account> accEntry = new HashMap<Long,Account>();
	static HashMap<Integer,Transaction>transEntry = new HashMap<Integer,Transaction>();
	
	public static HashMap<Long,Account> getAccounts(){
		return accEntry;
	}
	
	public static HashMap<Integer, Transaction> getTransactions(){
		return transEntry;
	}
	
}
